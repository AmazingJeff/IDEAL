---
tags:
- translation

language:
- ar
- en

license: mit
---
### mbart-large-ar-en
This is mbart-large-cc25, finetuned on a subset of the OPUS corpus for ar_en.   
Usage: see [example notebook](https://colab.research.google.com/drive/1I6RFOWMaTpPBX7saJYjnSTddW0TD6H1t?usp=sharing)  
Note: model has limited training set, not fully trained (do not use for production).   
Other models by me: [Abed Khooli](https://huggingface.co/akhooli)  
