---
language: de
license: mit
---

# bert-german-dbmdz-uncased-sentence-stsb
**This model is outdated!**

The new [T-Systems-onsite/cross-en-de-roberta-sentence-transformer](https://huggingface.co/T-Systems-onsite/cross-en-de-roberta-sentence-transformer) model is better for German language. It is also the current best model for English language and works cross-lingually. Please consider using that model.