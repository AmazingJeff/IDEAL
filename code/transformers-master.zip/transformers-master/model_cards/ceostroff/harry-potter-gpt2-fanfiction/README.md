---
language: 
- en
tags:
- harry-potter
license: mit
---

# Harry Potter Fanfiction Generator

This is a pre-trained GPT-2 generative text model that allows you to generate your own Harry Potter fanfiction, trained off of the top 100 rated fanficition stories. We intend for this to be used for individual fun and experimentation and not as a commercial product. 
